docker rm -f nginx_nginx_1 && docker-compose up -d
